//control statement
// loan guaranting program

 import java.util.*;

class loan{
 public static void main(String[] args){

 Scanner contractYears=new Scanner(System.in);
Scanner  s=new Scanner(System.in);
         
         System.out.println("enter years of contract please!");
          int yearsOfcontract=contractYears.nextInt();
         System.out.println("enter salary");
          int salary=s.nextInt();

 if(yearsOfcontract<4 || salary<100000){
 System.out.println("you are not allowed for aloan");
}
else{
    System.out.println("you are allowed to get aloan");
}
 
}
}