//control statement to check if you are eligible to vote
import java.util.*;
class vote{
public static void main(String[] args){
  Scanner obj=new Scanner(System.in);
 System.out.println("enter years to check if you are eligible to vote");
  int years=obj.nextInt();

if(years<18){
System.out.println("you are not allowed to vote");
}
else{
System.out.println("you are eligible to vote");
}
}
}