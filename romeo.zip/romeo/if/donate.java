//if statement to check if you are allowed to drive
//you can donate if you above 18yrs and above 56 kg


 import java.util.*;

class donate{
 public static void main(String[] args){

 Scanner contractYears=new Scanner(System.in);
Scanner  d=new Scanner(System.in);
         
         System.out.println("enter your age please!");
          int age=d.nextInt();
         System.out.println("enter your weight");
          int kg=d.nextInt();

 if(kg>56 && age>18){
 System.out.println("you are allowed to donate");
}
else{
    System.out.println("you can't donate");
}
 
}
}
