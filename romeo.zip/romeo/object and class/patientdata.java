//java object and class
// program to access patient data by using object

class patient{
 int id=12554;
 String name="mugabo"; 
}
class patientdata{  
   
 public static void main(String args[]){  

  patient p1=new patient(); //creating patient's object --p1--
  System.out.println("patient id is: "+p1.id);  
  System.out.println("patient name is: "+p1.name);  
 }  
}  
