 
class school{  
 int id=888;
 String schoolname="ES Kigoma"; 
 String province="south";
 
 public static void main(String args[]){  
   school p=new school();  
   System.out.println("school id is:"+p.id);  
   System.out.println("school schoolname is:"+p.schoolname);  
   System.out.println("school schoolname is:"+p.province); 
}  
}  