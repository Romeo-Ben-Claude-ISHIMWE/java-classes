//java object and class



class employee{  
   int id=23456;
   int salary=50000;
   String name="berry";
   String position="HRM";
 public static void main(String args[]){  

  employee Emp=new employee(); //creating employee object --Emp--
  System.out.println("Employee id is: "+Emp.id);  
  System.out.println("Employee name is: "+Emp.name);  
  System.out.println("Employee position is: "+Emp.position);  
  System.out.println("Employee salary is: "+Emp.salary);  
 }  
}  