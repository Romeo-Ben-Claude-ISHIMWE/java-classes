// program to print fruit types

class fruits{  
void  types(){System.out.println("there are many types of fruits");}  
}  
class mango extends fruits{  
void type1(){System.out.println("mango is one of the fruits types");}  
}  
class fruitss{  
public static void main(String args[]){  
mango d=new mango();  
d.types();  
d.type1();  
 
}}  