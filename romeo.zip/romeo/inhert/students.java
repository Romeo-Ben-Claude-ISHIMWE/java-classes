class classroom{  
 String studentName="john";
}  
class students extends classroom{  
 int marks=60;  
 public static void main(String args[]){  
   students p=new students();  
   System.out.println("student name is:"+p.studentName);  
   System.out.println("student marks is:"+p.marks);  
}  
}  