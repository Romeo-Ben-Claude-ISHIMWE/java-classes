 //overloading in java

class Overloadingaddition{  
  void add(int a,int b){System.out.println(a+b);}  
  void add(int a,int b,int c){System.out.println(a+b+c);}  
  
  public static void main(String args[]){  
  Overloadingaddition obj=new Overloadingaddition();  
  obj.add(2,20);
  obj.add(5,15,30);  
  
  }  
}  