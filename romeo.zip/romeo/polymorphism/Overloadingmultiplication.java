 //overloading in java


class Overloadingmultiplication{  
  void multiply(int a,int b){System.out.println("3*7 equals: "+(a*b));}  
  void multiply(int a,int b,int c){System.out.println("3*7*2 equals: "+(a*b*c));}  
  
  public static void main(String args[]){  
  Overloadingmultiplication obj=new Overloadingmultiplication();  
  obj.multiply(3,7);
  obj.multiply(3,7,2);  
  
  }  
}  