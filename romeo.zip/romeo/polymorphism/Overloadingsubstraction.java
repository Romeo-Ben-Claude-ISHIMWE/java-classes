 //overloading in java


class Overloadingsubstraction{  
  void substract(int a,int b){System.out.println("a-b equals: "+(a-b));}  
  void substract(int a,int b,int c){System.out.println("a-b-c equals: "+(a-b-c));}  
  
  public static void main(String args[]){  
  Overloadingsubstraction obj=new Overloadingsubstraction();  
  obj.substract(56,20);
  obj.substract(70,15,30);  
  
  }  
}  